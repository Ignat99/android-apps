package com.example;

/**
 * Created by IntelliJ IDEA.
 * User: frol
 * Date: 01.12.10
 * Time: 19:03
 * To change this template use File | Settings | File Templates.
 */
public interface WinnerCheckerInterface {
    public Player checkWinner();
}
